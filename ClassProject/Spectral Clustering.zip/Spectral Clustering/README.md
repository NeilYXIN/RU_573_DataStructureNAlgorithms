README
This program is based on the Scikit-Learn.

To change the dataset, modify the filename of the csv reader.
Then change the X and y accordingly based on your data.

To change the kernel function, change the 'poly' in y_pred into 'nearest_neighbors' or 'sigmoid' or 'rbf'.
Adjust related parameters until the result is good enough.

Dataset:
UCI: wine dataset, iris dataset
